package com.ahom.hrms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RaiseGrievances {
	
	@Id
	private String grievanceType;
	private String title;
	private String uploadAttechment;
	private String description;
	
	
	public String getGrievanceType() {
		return grievanceType;
	}
	public void setGrievanceType(String grievanceType) {
		this.grievanceType = grievanceType;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getUploadAttechment() {
		return uploadAttechment;
	}
	public void setUploadAttechment(String uploadAttechment) {
		this.uploadAttechment = uploadAttechment;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	@Override
	public String toString() {
		return "RaiseGrievances [grievanceType=" + grievanceType + ", title=" + title + ", uploadAttechment="
				+ uploadAttechment + ", description=" + description + "]";
	}
	

}
