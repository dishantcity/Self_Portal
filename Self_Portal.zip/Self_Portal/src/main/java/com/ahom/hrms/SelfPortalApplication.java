package com.ahom.hrms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SelfPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SelfPortalApplication.class, args);
	}

}
