package com.ahom.hrms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MonthlyPerformance {
	
	
	@Id
	private int employeeId;
	
	private int reportAuth;
	private String name;
	private String department;
	private String designation;
	private String dateOfJoining;
	private String reportingMonth;
	private String reportingTime;
	private String description;
	private String status;
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getReportAuth() {
		return reportAuth;
	}
	public void setReportAuth(int reportAuth) {
		this.reportAuth = reportAuth;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getReportingMonth() {
		return reportingMonth;
	}
	public void setReportingMonth(String reportingMonth) {
		this.reportingMonth = reportingMonth;
	}
	public String getReportingTime() {
		return reportingTime;
	}
	public void setReportingTime(String reportingTime) {
		this.reportingTime = reportingTime;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	@Override
	public String toString() {
		return "MonthlyPerformance [employeeId=" + employeeId + ", reportAuth=" + reportAuth + ", name=" + name
				+ ", department=" + department + ", designation=" + designation + ", dateOfJoining=" + dateOfJoining
				+ ", reportingMonth=" + reportingMonth + ", reportingTime=" + reportingTime + ", description="
				+ description + ", status=" + status + "]";
	}
	
	
	
	

}
