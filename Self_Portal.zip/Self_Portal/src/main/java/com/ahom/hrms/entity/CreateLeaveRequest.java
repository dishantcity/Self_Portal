package com.ahom.hrms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CreateLeaveRequest {
	
	@Id
	private Double availableBalance;
	private String selectEmployee;
	private String leaveApprover;
	private String leaveType;
	private String leaveFor;
	private String startDate;
	private String endDate;
	private String days;
	private String reasonForLeave;
	
	
	public Double getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(Double availableBalance) {
		this.availableBalance = availableBalance;
	}
	public String getSelectEmployee() {
		return selectEmployee;
	}
	public void setSelectEmployee(String selectEmployee) {
		this.selectEmployee = selectEmployee;
	}
	public String getLeaveApprover() {
		return leaveApprover;
	}
	public void setLeaveApprover(String leaveApprover) {
		this.leaveApprover = leaveApprover;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public String getLeaveFor() {
		return leaveFor;
	}
	public void setLeaveFor(String leaveFor) {
		this.leaveFor = leaveFor;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getDays() {
		return days;
	}
	public void setDays(String days) {
		this.days = days;
	}
	public String getReasonForLeave() {
		return reasonForLeave;
	}
	public void setReasonForLeave(String reasonForLeave) {
		this.reasonForLeave = reasonForLeave;
	}
	
	
	@Override
	public String toString() {
		return "CreateLeaveRequest [availableBalance=" + availableBalance + ", selectEmployee=" + selectEmployee
				+ ", leaveApprover=" + leaveApprover + ", leaveType=" + leaveType + ", leaveFor=" + leaveFor
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", days=" + days + ", reasonForLeave="
				+ reasonForLeave + "]";
	}
	
	

}
