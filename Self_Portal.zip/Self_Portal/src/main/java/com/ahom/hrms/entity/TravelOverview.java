package com.ahom.hrms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TravelOverview {
	
	@Id
	private String branchMaster;
	private String searchBranchName;
	
	
	public String getBranchMaster() {
		return branchMaster;
	}
	public void setBranchMaster(String branchMaster) {
		this.branchMaster = branchMaster;
	}
	public String getSearchBranchName() {
		return searchBranchName;
	}
	public void setSearchBranchName(String searchBranchName) {
		this.searchBranchName = searchBranchName;
	}
	
	
	@Override
	public String toString() {
		return "TravelOverview [branchMaster=" + branchMaster + ", searchBranchName=" + searchBranchName + "]";
	}
	
	
	

}
