package com.ahom.hrms.dto;

public class RaiseGrievancesDto {
	
	private String grievanceType;
	private String title;
	private String uploadAttechment;
	private String description;
	
	
	public String getGrievanceType() {
		return grievanceType;
	}
	public void setGrievanceType(String grievanceType) {
		this.grievanceType = grievanceType;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getUploadAttechment() {
		return uploadAttechment;
	}
	public void setUploadAttechment(String uploadAttechment) {
		this.uploadAttechment = uploadAttechment;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	@Override
	public String toString() {
		return "RaiseGrievancesDto [grievanceType=" + grievanceType + ", title=" + title + ", uploadAttechment="
				+ uploadAttechment + ", description=" + description + "]";
	}
	

}
